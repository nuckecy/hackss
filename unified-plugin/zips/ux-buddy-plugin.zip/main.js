// src/main.ts
figma.showUI(__html__, { width: 414, height: 667 });
function extractSelectionData(node) {
  try {
    const data = {
      id: node.id,
      name: node.name,
      type: node.type,
      width: node.width,
      height: node.height
    };
    if (node.type === "INSTANCE") {
      try {
        if (node.mainComponent) {
          data.componentName = node.mainComponent.name;
        }
        const variantProps = node.variantProperties;
        if (variantProps) {
          data.variantProperties = variantProps;
        }
      } catch (_) {
      }
    }
    if (node.type === "TEXT") {
      try {
        const fontSize = node.fontSize;
        if (typeof fontSize === "number") {
          data.fontSize = fontSize;
        }
        const fontName = node.fontName;
        if (fontName && typeof fontName === "object" && "family" in fontName) {
          data.fontName = {
            family: fontName.family,
            style: fontName.style
          };
        }
        const lineHeight = node.lineHeight;
        if (lineHeight && typeof lineHeight === "object" && "value" in lineHeight) {
          const lh = lineHeight;
          data.lineHeight = { value: lh.value, unit: lh.unit };
        }
        data.characters = node.characters.substring(0, 200);
      } catch (_) {
      }
    }
    if ("fills" in node) {
      try {
        const fills = node.fills;
        if (Array.isArray(fills)) {
          data.fills = fills.filter((f) => f.type === "SOLID").map((f) => ({
            type: f.type,
            color: {
              r: f.color.r,
              g: f.color.g,
              b: f.color.b
            },
            opacity: f.opacity
          }));
        }
      } catch (_) {
      }
    }
    if ("strokes" in node) {
      try {
        const strokes = node.strokes;
        if (Array.isArray(strokes)) {
          data.strokes = strokes.filter((s) => s.type === "SOLID").map((s) => ({
            type: s.type,
            color: {
              r: s.color.r,
              g: s.color.g,
              b: s.color.b
            }
          }));
        }
      } catch (_) {
      }
    }
    if ("layoutMode" in node) {
      try {
        const layoutNode = node;
        data.layoutMode = layoutNode.layoutMode;
        if (layoutNode.layoutMode !== "NONE") {
          data.itemSpacing = layoutNode.itemSpacing;
          data.paddingTop = layoutNode.paddingTop;
          data.paddingRight = layoutNode.paddingRight;
          data.paddingBottom = layoutNode.paddingBottom;
          data.paddingLeft = layoutNode.paddingLeft;
        }
      } catch (_) {
      }
    }
    if ("children" in node) {
      try {
        const parentNode = node;
        data.childrenSummary = parentNode.children.slice(0, 10).map((child) => {
          const summary = {
            name: child.name,
            type: child.type
          };
          if (child.type === "INSTANCE" && child.mainComponent) {
            summary.componentName = child.mainComponent.name;
          }
          return summary;
        });
      } catch (_) {
      }
    }
    return data;
  } catch (_) {
    return null;
  }
}
function sendCurrentSelection() {
  const selection = figma.currentPage.selection;
  if (selection.length === 0) {
    figma.ui.postMessage({ type: "selection-changed", data: null });
    return;
  }
  const data = extractSelectionData(selection[0]);
  figma.ui.postMessage({ type: "selection-changed", data });
}
figma.on("selectionchange", () => {
  sendCurrentSelection();
});
figma.ui.onmessage = async (msg) => {
  if (msg.type === "request-selection") {
    sendCurrentSelection();
  } else if (msg.type === "get-api-key") {
    const key = await figma.clientStorage.getAsync("gemini-api-key");
    figma.ui.postMessage({ type: "api-key-response", key: key || null });
  } else if (msg.type === "save-api-key" && msg.key) {
    await figma.clientStorage.setAsync("gemini-api-key", msg.key);
    figma.ui.postMessage({ type: "api-key-saved" });
  } else if (msg.type === "clear-api-key") {
    await figma.clientStorage.deleteAsync("gemini-api-key");
    figma.ui.postMessage({ type: "api-key-cleared" });
  }
};
sendCurrentSelection();
figma.ui.postMessage({ type: "plugin-ready" });
